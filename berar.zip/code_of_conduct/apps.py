from django.apps import AppConfig


class CodeOfConductConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'code_of_conduct'
